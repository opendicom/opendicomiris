/*============================================================================
  MetaIO
  Copyright 2000-2011 Insight Software Consortium

  Distributed under the OSI-approved BSD License (the "License");
  see accompanying file Copyright.txt for details.

  This software is distributed WITHOUT ANY WARRANTY; without even the
  implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
  See the License for more information.
============================================================================*/
#undef METAIO_FOR_VTK
#undef METAIO_FOR_ITK
#define METAIO_FOR_VTK
/* #undef METAIO_FOR_ITK */
