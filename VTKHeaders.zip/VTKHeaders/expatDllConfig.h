#ifndef _expatDllConfig_h
#define _expatDllConfig_h

/* #undef VTK_EXPAT_STATIC */

#endif
